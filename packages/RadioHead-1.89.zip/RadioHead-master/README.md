# RadioHead Arduino Library

A GitHub mirror of the RadioHead library by Mike McCauley.

Original library and documentation: <http://www.airspayce.com/mikem/arduino/RadioHead/>

Help and discussion: <http://groups.google.com/group/radiohead-arduino>

RadioHead is a trademark of AirSpayce Pty Ltd.

Copyright (C) 2011-2021 Mike McCauley.

Open Source License: GPL V3 <https://www.gnu.org/licenses/gpl-3.0.html>

To purchase a commercial license, contact: <info@airspayce.com>
